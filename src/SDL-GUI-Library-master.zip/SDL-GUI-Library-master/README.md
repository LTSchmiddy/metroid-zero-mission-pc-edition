SDL-GUI-Library
===============

This is an open-source, cross-platform C++ GUI Library built on top of the SDL Framework.

The intent is to produce a modern, object-oriented, exception-capable C++ GUI library.

